
using UnityEngine;

namespace ATC.Operator.CommandView {
    public class CommandController : ATC_Operator_Sub_Controller {
        [Header("Data")]
        [SerializeField] internal ArrivalCommandData arrCommandData;
        [SerializeField] internal DepartureCommandData depCommandData;
        [SerializeField] internal ParkingPathData parkingPathData;
        [SerializeField] internal AirplaneData[] allAirplaneData;

        [Header("Child Script")]
        [SerializeField] internal Command_Node_Controller cmdNodeController;
        [SerializeField] internal Command_Parameter_Controller cmdParamController;
        [SerializeField] internal Command_FlightCreation_Controller cmdFlightCreationController;

        internal override void Initialize(ATC_Operator_Main_Controller _mainController) {
            base.Initialize(_mainController);

            cmdNodeController.Initialize(this);
            cmdParamController.Initialize(this);
            cmdFlightCreationController.Initialize(this);
        }
    }
}