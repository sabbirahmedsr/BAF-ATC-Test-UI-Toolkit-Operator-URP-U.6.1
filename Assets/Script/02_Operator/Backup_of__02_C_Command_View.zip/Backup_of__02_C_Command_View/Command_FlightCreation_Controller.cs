using ATC.Global;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using static TMPro.TMP_Dropdown;

namespace ATC.Operator.CommandView {
    /// <summery>
    /// Arrival Command Controller Create Arrival Aircraft/Flight
    /// </summery>
    [System.Serializable]   
    public class Command_FlightCreation_Controller {

        internal TypeOfAircraft selectedCategory = TypeOfAircraft.International;
        internal AirplaneData selectedApData = null;
        internal ushort selectedRerportingPoint = 0;
        internal ParkingStandID selectedParkingStandID = ParkingStandID._05;

        internal List<TypeOfAircraft> result_category = new List<TypeOfAircraft>();
        internal List<AirplaneData> result_apData = new List<AirplaneData>();

        internal CommandController cmdCtrl;
        private Cmd_FlightCreation_UI ui = new Cmd_FlightCreation_UI();

        internal void Initialize(CommandController rCmdCtrl) {
            cmdCtrl = rCmdCtrl;
            //
            ui.Initialize(this);
            //
            Refresh_CategoryOptions();
            Refresh_ApData_basedOnCategory();
            Refresh_ReportingPoint_basedOnCallSign();
        }



        private void Refresh_CategoryOptions() {
            TypeOfAircraft[] allCategory = (TypeOfAircraft[])Enum.GetValues(typeof(TypeOfAircraft));
            result_category.Clear();
            // Note : we have to skip the first type as it is set as none [thats why, i = 1]
            for (int i = 1; i < allCategory.Length; i++) {
                result_category.Add(allCategory[i]);
            }
            selectedCategory = allCategory[0];
            ui.Refresh_DrdCategoryOptions(0);
        }
        private void Refresh_ApData_basedOnCategory() {
            result_apData.Clear();
            for (int i = 0; i < cmdCtrl.allAirplaneData.Length; i++) {
                if (cmdCtrl.allAirplaneData[i].aircraftType == selectedCategory) {
                    result_apData.Add(cmdCtrl.allAirplaneData[i]);
                }
            }
            UnityEngine.Debug.Log(result_apData.Count);
            selectedApData = result_apData[0];
            ui.Refresh_DrdCallSignOptions(0);
        }
        private void Refresh_ReportingPoint_basedOnCallSign() {
            int lastIndex = selectedApData.allPreArrivalPoints.Length - 1;
            selectedRerportingPoint = (ushort)lastIndex;
            ui.Refresh_DrdReportingPointOptions(lastIndex);
        }




        public void OnDrdChange_Catergory(int rIndex) {
            selectedCategory = result_category[rIndex];
            Refresh_ApData_basedOnCategory();
            Refresh_ReportingPoint_basedOnCallSign();
        }
        public void OnDrdChange_CallSign(int rIndex) {
            selectedApData = result_apData[rIndex];
            Refresh_ReportingPoint_basedOnCallSign();
        }
        public void OnDrdChange_ReportingPoint(int rIndex) {
            selectedRerportingPoint = (ushort)rIndex;
        }
        public void OnDrdChange_ParkingStand(int rIndex) {
            selectedParkingStandID = selectedApData.allParkingStandID[rIndex];
        }







        internal void Create_ArrFlight_OnServer() {
            GlobalNetwork.actionSender.Create_ArrFlight_OnServer(selectedApData.callSign, selectedRerportingPoint);
        }

        internal void Create_DepFlight_OnServer() {
            GlobalNetwork.actionSender.Create_DepFlight_OnServer(selectedApData.callSign, selectedParkingStandID);
        }
        

    }
}